import { Component, OnInit } from '@angular/core';
import { Paper} from '../models/paper';
import { Option} from '../models/option';
import { FormBuilder, FormArray} from '@angular/forms';
import { IFormBuilder,IFormGroup, IFormArray} from "@rxweb/types";

@Component({
  selector: 'app-paper',
  templateUrl: './paper.component.html',
  styleUrls: ['./paper.component.css']
})
export class PaperComponent implements OnInit {

  formGroup: IFormGroup<Paper>;
  formBuilder: IFormBuilder;
  arr = null
  paperNames = [
    {
      id : 1,
      name : "Machine Learning"
    },
    {
      id : 2,
      name : "Artificial Intelligence"
    },
    {
      id : 3,
      name : "Data Science"
    }
  ];

  constructor(formBuilder: FormBuilder) {
    this.formBuilder = formBuilder;   
    this.formGroup = this.formBuilder.group<Paper>({
      paperName : [''],
      question: [''],
      answer: [''],
      options: this.formBuilder.array<Option>([
        this.formBuilder.group({
          nameOfOption:['']
        })
      ])
    })
  }

  ngOnInit(): void {  
    
  }

  addOption() {
    this.arr = this.formGroup.get("options")
    console.log(typeof this.arr);
  }

  submit(){
    console.log(this.formGroup.value)
  }

}
