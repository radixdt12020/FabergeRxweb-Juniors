export interface Option{
    nameOfOption:string;
}