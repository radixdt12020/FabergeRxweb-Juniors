import {Option} from './option'
export interface Paper{

    paperName : string;

    question : string;

    answer : string;

    options : Option[];
}